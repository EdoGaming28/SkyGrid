<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\island;


use pocketmine\level\Level;
use ReflectionException;
use skintrphoenix\AcidIsland\event\island\IslandCreateEvent;
use skintrphoenix\AcidIsland\event\island\IslandDisbandEvent;
use skintrphoenix\AcidIsland\island\generator\IslandGenerator;
use skintrphoenix\AcidIsland\session\Session;
use skintrphoenix\AcidIsland\AcidIsland;
use skintrphoenix\AcidIsland\utils\message\MessageContainer;

class IslandFactory {

    public static function createIslandWorld(string $identifier, string $type): Level {
        $AcidIsland = AcidIsland::getInstance();

        $generatorManager = $AcidIsland->getGeneratorManager();
        if($generatorManager->isGenerator($type)) {
            $generator = $generatorManager->getGenerator($type);
        } else {
            $generator = $generatorManager->getGenerator("Basic");
        }

        $server = $AcidIsland->getServer();
        $server->generateLevel($identifier, null, $generator);
        $server->loadLevel($identifier);
        $level = $server->getLevelByName($identifier);
        /** @var IslandGenerator $generator */
        $level->setSpawnLocation($generator::getWorldSpawn());

        return $level;
    }

    /**
     * @throws ReflectionException
     */
    public static function createIslandFor(Session $session, string $type): void {
        $identifier = uniqid("sb-");
        $islandManager = AcidIsland::getInstance()->getIslandManager();

        $islandManager->openIsland($identifier, [$session->getOfflineSession()], true, $type,
            self::createIslandWorld($identifier, $type), 0);

        $session->setIsland($island = $islandManager->getIsland($identifier));
        $session->setRank(RankIds::FOUNDER);
        $session->setLastIslandCreationTime(microtime(true));
        $session->getPlayer()->teleport($island->getSpawnLocation());

        $session->save();
        $island->save();

        (new IslandCreateEvent($island))->call();
    }

    /**
     * @throws ReflectionException
     */
    public static function disbandIsland(Island $island): void {
        foreach($island->getLevel()->getPlayers() as $player) {
            $player->teleport($player->getServer()->getDefaultLevel()->getSpawnLocation());
        }
        foreach($island->getMembers() as $offlineMember) {
            $onlineSession = $offlineMember->getOnlineSession();
            if($onlineSession != null) {
                $onlineSession->setIsland(null);
                $onlineSession->setRank(RankIds::MEMBER);
                $onlineSession->save();
                $onlineSession->sendTranslatedMessage(new MessageContainer("ISLAND_DISBANDED"));
            } else {
                $offlineMember->setIslandId(null);
                $offlineMember->setRank(RankIds::MEMBER);
                $offlineMember->save();
            }
        }
        $island->setMembers([]);
        $island->save();
        AcidIsland::getInstance()->getIslandManager()->closeIsland($island);
        (new IslandDisbandEvent($island))->call();
    }

}