<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\island;


use pocketmine\level\Level;
use skintrphoenix\AcidIsland\event\island\IslandOpenEvent;
use skintrphoenix\AcidIsland\event\island\IslandCloseEvent;
use skintrphoenix\AcidIsland\AcidIsland;

class IslandManager {

    /** @var AcidIsland */
    private $plugin;

    /** @var Island[] */
    private $islands = [];

    public function __construct(AcidIsland $plugin) {
        $this->plugin = $plugin;
        $plugin->getServer()->getPluginManager()->registerEvents(new IslandListener($this), $plugin);
    }

    public function getPlugin(): AcidIsland {
        return $this->plugin;
    }

    /**
     * @return Island[]
     */
    public function getIslands(): array {
        return $this->islands;
    }

    public function getIsland(string $identifier): ?Island {
        return $this->islands[$identifier] ?? null;
    }

    public function getIslandByLevel(Level $level): ?Island {
        return $this->getIsland($level->getName());
    }

    public function openIsland(string $identifier, array $members, bool $locked, string $type, Level $level, int $blocksBuilt): void {
        $this->islands[$identifier] = new Island($this, $identifier, $members, $locked, $type, $level, $blocksBuilt);
        (new IslandOpenEvent($this->islands[$identifier]))->call();
    }

    public function closeIsland(Island $island): void {
        $island->save();
        $server = $this->plugin->getServer();
        (new IslandCloseEvent($island))->call();
        $server->unloadLevel($island->getLevel());
        unset($this->islands[$island->getIdentifier()]);
    }

}