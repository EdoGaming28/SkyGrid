<?php


namespace skintrphoenix\AcidIsland\island;


interface RankIds {

    public const MEMBER = 0;
    public const OFFICER = 1;
    public const LEADER = 2;
    public const FOUNDER = 3;

}