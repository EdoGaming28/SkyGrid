<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\session;


use pocketmine\Player;
use ReflectionException;
use skintrphoenix\AcidIsland\event\session\SessionCloseEvent;
use skintrphoenix\AcidIsland\event\session\SessionOpenEvent;
use skintrphoenix\AcidIsland\AcidIsland;

class SessionManager {

    /** @var AcidIsland */
    private $plugin;

    /** @var Session[] */
    private $sessions = [];

    public function __construct(AcidIsland $plugin) {
        $this->plugin = $plugin;
        $plugin->getServer()->getPluginManager()->registerEvents(new SessionListener($this), $plugin);
    }

    public function getPlugin(): AcidIsland {
        return $this->plugin;
    }

    /**
     * @return Session[]
     */
    public function getSessions(): array {
        return $this->sessions;
    }

    /**
     * @throws ReflectionException
     */
    public function getSession(Player $player): Session {
        if(!$this->isSessionOpen($player)) {
            $this->openSession($player);
        }
        return $this->sessions[$player->getName()];
    }

    public function isSessionOpen(Player $player): bool {
        return isset($this->sessions[$player->getName()]);
    }

    public function getOfflineSession(string $username): ?OfflineSession {
        return new OfflineSession($this, $username);
    }

    /**
     * @throws ReflectionException
     */
    public function openSession(Player $player): void {
        $this->sessions[$username = $player->getName()] = new Session($this, $player);
        (new SessionOpenEvent($this->sessions[$username]))->call();
    }

    /**
     * @throws ReflectionException
     */
    public function closeSession(Player $player): void {
        if(isset($this->sessions[$username = $player->getName()])) {
            $session = $this->sessions[$username];
            $session->save();
            (new SessionCloseEvent($session))->call();
            unset($this->sessions[$username]);
            if($session->hasIsland()) {
                $session->getIsland()->tryToClose();
            }
        }
    }

}