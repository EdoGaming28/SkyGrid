<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\session;


use ReflectionException;

class OfflineSession extends BaseSession {

    /**
     * @throws ReflectionException
     */
    public function getOnlineSession(): ?Session {
        $player = $this->manager->getPlugin()->getServer()->getPlayerExact($this->lowerCaseName);
        if($player != null) {
            return $this->manager->getSession($player);
        }
        return null;
    }

}