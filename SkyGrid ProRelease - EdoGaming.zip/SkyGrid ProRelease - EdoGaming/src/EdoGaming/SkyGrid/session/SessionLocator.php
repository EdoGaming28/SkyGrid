<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\session;


use pocketmine\Player;
use ReflectionException;
use skintrphoenix\AcidIsland\AcidIsland;

class SessionLocator {

    /**
     * @throws ReflectionException
     */
    public static function getSession(Player $player): Session {
        return AcidIsland::getInstance()->getSessionManager()->getSession($player);
    }

    public static function getOfflineSession(string $username): OfflineSession {
        return AcidIsland::getInstance()->getSessionManager()->getOfflineSession($username);
    }

    public static function isSessionOpen(Player $player): bool {
        return AcidIsland::getInstance()->getSessionManager()->isSessionOpen($player);
    }

}