<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\session;


use pocketmine\event\Listener;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerQuitEvent;
use ReflectionException;

class SessionListener implements Listener {

    /** @var SessionManager */
    private $manager;

    public function __construct(SessionManager $manager) {
        $this->manager = $manager;
    }

    /**
     * @throws ReflectionException
     */
    public function onLogin(PlayerLoginEvent $event): void {
        $this->manager->openSession($event->getPlayer());
    }

    /**
     * @throws ReflectionException
     */
    public function onQuit(PlayerQuitEvent $event): void {
        $this->manager->closeSession($event->getPlayer());
    }

}