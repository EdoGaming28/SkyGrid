<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\utils\message;


use skintrphoenix\AcidIsland\AcidIsland;

class MessageContainer {

    /** @var string */
    private $messageId;

    /** @var array */
    private $arguments = [];

    public function __construct(string $messageId, array $arguments = []) {
        $this->messageId = $messageId;
        $this->arguments = $arguments;
    }

    public function getMessageId(): string {
        return $this->messageId;
    }

    public function getArguments(): array {
        return $this->arguments;
    }

    public function getMessage(): string {
        return AcidIsland::getInstance()->getMessageManager()->getMessage($this);
    }

}