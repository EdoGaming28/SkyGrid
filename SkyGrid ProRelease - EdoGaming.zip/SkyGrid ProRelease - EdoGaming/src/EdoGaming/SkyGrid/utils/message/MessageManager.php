<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\utils\message;


use skintrphoenix\AcidIsland\AcidIsland;
use skintrphoenix\AcidIsland\utils\Utils;

class MessageManager {

    /** @var string[] */
    private $messages;

    public function __construct(AcidIsland $plugin) {
        $this->messages = json_decode(file_get_contents($plugin->getDataFolder() . "messages.json"), true);
    }

    /**
     * @return string[]
     */
    public function getMessages(): array {
        return $this->messages;
    }

    public function getMessage(MessageContainer $container): string {
        $identifier = $container->getMessageId();
        $message = $this->messages[$identifier] ?? "Message ($identifier) not found";
        $message = Utils::translateColors($message);
        foreach($container->getArguments() as $arg => $value) {
            $message = str_replace("{" . $arg . "}", $value, $message);
        }
        return $message;
    }

    public function addMessage(string $identifier, string $message): void {
        $this->messages[$identifier] = $message;
    }

}