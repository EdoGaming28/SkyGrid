<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\event\session;


use skintrphoenix\AcidIsland\event\AcidIslandEvent;
use skintrphoenix\AcidIsland\session\Session;

abstract class SessionEvent extends AcidIslandEvent {

    /** @var Session */
    private $session;

    public function __construct(Session $session) {
        $this->session = $session;
    }

    public function getSession(): Session {
        return $this->session;
    }

}