<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\event\session;


class SessionOpenEvent extends SessionEvent {

}