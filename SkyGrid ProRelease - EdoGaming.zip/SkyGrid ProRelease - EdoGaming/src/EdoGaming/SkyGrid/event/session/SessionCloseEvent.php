<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\event\session;


class SessionCloseEvent extends SessionEvent {

}