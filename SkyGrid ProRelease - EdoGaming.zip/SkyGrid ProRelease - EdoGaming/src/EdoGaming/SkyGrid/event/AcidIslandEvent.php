<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\event;


use pocketmine\event\Event;

abstract class AcidIslandEvent extends Event {

}