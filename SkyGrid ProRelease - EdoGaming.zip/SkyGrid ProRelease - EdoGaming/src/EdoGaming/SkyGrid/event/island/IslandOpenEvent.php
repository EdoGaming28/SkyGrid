<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\event\island;


class IslandOpenEvent extends IslandEvent {

}