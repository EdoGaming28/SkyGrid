<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\event\island;


use skintrphoenix\AcidIsland\event\AcidIslandEvent;
use skintrphoenix\AcidIsland\island\Island;

abstract class IslandEvent extends AcidIslandEvent {

    /** @var Island */
    private $island;

    public function __construct(Island $island) {
        $this->island = $island;
    }

    public function getIsland(): Island {
        return $this->island;
    }

}