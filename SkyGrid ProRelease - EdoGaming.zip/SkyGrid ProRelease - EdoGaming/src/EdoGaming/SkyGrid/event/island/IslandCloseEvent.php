<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\event\island;


class IslandCloseEvent extends IslandEvent {

}