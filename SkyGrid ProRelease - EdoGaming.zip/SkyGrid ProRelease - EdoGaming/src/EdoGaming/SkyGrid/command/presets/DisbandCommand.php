<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\command\presets;


use ReflectionException;
use skintrphoenix\AcidIsland\command\IslandCommand;
use skintrphoenix\AcidIsland\command\IslandCommandMap;
use skintrphoenix\AcidIsland\island\IslandFactory;
use skintrphoenix\AcidIsland\island\IslandManager;
use skintrphoenix\AcidIsland\session\Session;
use skintrphoenix\AcidIsland\utils\message\MessageContainer;

class DisbandCommand extends IslandCommand {

    /** @var IslandManager */
    private $islandManager;

    public function __construct(IslandCommandMap $map) {
        $this->islandManager = $map->getPlugin()->getIslandManager();
    }

    public function getName(): string {
        return "disband";
    }

    public function getUsageMessageContainer(): MessageContainer {
        return new MessageContainer("DISBAND_USAGE");
    }

    public function getDescriptionMessageContainer(): MessageContainer {
        return new MessageContainer("DISBAND_DESCRIPTION");
    }

    /**
     * @throws ReflectionException
     */
    public function onCommand(Session $session, array $args): void {
        if($this->checkFounder($session)) {
            return;
        }
        IslandFactory::disbandIsland($session->getIsland());
    }

}
