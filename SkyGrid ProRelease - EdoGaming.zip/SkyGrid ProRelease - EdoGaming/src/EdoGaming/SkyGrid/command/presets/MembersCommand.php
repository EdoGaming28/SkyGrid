<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\command\presets;


use ReflectionException;
use skintrphoenix\AcidIsland\command\IslandCommand;
use skintrphoenix\AcidIsland\session\Session;
use skintrphoenix\AcidIsland\utils\message\MessageContainer;

class MembersCommand extends IslandCommand {

    public function getName(): string {
        return "members";
    }

    public function getUsageMessageContainer(): MessageContainer {
        return new MessageContainer("MEMBERS_USAGE");
    }

    public function getDescriptionMessageContainer(): MessageContainer {
        return new MessageContainer("MEMBERS_DESCRIPTION");
    }

    /**
     * @throws ReflectionException
     */
    public function onCommand(Session $session, array $args): void {
        if($this->checkIsland($session)) {
            return;
        }
        $members = $session->getIsland()->getMembers();
        $session->sendTranslatedMessage(new MessageContainer("MEMBERS_COMMAND_HEADER", [
            "amount" => count($members)
        ]));
        foreach($members as $member) {
            $memberSession = $member->getOnlineSession();
            if($memberSession != null) {
                $session->sendTranslatedMessage(new MessageContainer("ONLINE_MEMBER", [
                    "name" => $memberSession->getName()
                ]));
            } else {
                $session->sendTranslatedMessage(new MessageContainer("OFFLINE_MEMBER", [
                    "name" => $member->getLowerCaseName()
                ]));
            }
        }
    }

}