<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\command\presets;


use ReflectionException;
use skintrphoenix\AcidIsland\command\IslandCommand;
use skintrphoenix\AcidIsland\session\Session;
use skintrphoenix\AcidIsland\utils\message\MessageContainer;

class DenyCommand extends IslandCommand {

    public function getName(): string {
        return "deny";
    }

    public function getAliases(): array {
        return ["den", "d"];
    }

    public function getUsageMessageContainer(): MessageContainer {
        return new MessageContainer("DENY_USAGE");
    }

    public function getDescriptionMessageContainer(): MessageContainer {
        return new MessageContainer("DENY_DESCRIPTION");
    }

    /**
     * @throws ReflectionException
     */
    public function onCommand(Session $session, array $args): void {
        $invitation = null;
        if(isset($args[0]) and $session->hasInvitationFrom($args[0])) {
            $invitation = $session->getInvitationFrom($args[0]);
        } else {
            $invitation = $session->getLastInvitation();
        }

        if($invitation != null) {
            $invitation->deny();
        } else {
            $session->sendTranslatedMessage(new MessageContainer("DENY_USAGE"));
        }
    }

}