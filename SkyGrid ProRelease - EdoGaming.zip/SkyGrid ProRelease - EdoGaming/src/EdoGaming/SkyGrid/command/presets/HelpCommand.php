<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\command\presets;


use skintrphoenix\AcidIsland\command\IslandCommand;
use skintrphoenix\AcidIsland\command\IslandCommandMap;
use skintrphoenix\AcidIsland\session\Session;
use skintrphoenix\AcidIsland\utils\message\MessageContainer;

class HelpCommand extends IslandCommand {

    /** @var IslandCommandMap */
    private $map;

    public function __construct(IslandCommandMap $map) {
        $this->map = $map;
    }

    public function getName(): string {
        return "help";
    }

    public function getAliases(): array {
        return ["?"];
    }

    public function getUsageMessageContainer(): MessageContainer {
        return new MessageContainer("HELP_USAGE");
    }

    public function getDescriptionMessageContainer(): MessageContainer {
        return new MessageContainer("HELP_DESCRIPTION");
    }

    public function onCommand(Session $session, array $args): void {
        $session->sendTranslatedMessage(new MessageContainer("HELP_HEADER", [
            "amount" => count($this->map->getCommands())
        ]));

        foreach($this->map->getCommands() as $command) {
            $session->sendTranslatedMessage(new MessageContainer("HELP_COMMAND_TEMPLATE", [
                "name" => $command->getName(),
                "description" => $session->getMessage($command->getDescriptionMessageContainer()),
                "usage" => $session->getMessage($command->getUsageMessageContainer())
            ]));
        }
    }

}