<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\command\presets;


use skintrphoenix\AcidIsland\command\IslandCommand;
use skintrphoenix\AcidIsland\session\Session;
use skintrphoenix\AcidIsland\utils\message\MessageContainer;

class CategoryCommand extends IslandCommand {

    public function getName(): string {
        return "category";
    }

    public function getAliases(): array {
        return ["c"];
    }

    public function getUsageMessageContainer(): MessageContainer {
        return new MessageContainer("CATEGORY_USAGE");
    }

    public function getDescriptionMessageContainer(): MessageContainer {
        return new MessageContainer("CATEGORY_DESCRIPTION");
    }

    public function onCommand(Session $session, array $args): void {
        if($this->checkIsland($session)) {
            return;
        }
        $session->sendTranslatedMessage(new MessageContainer("ISLAND_CATEGORY", [
            "category" => $session->getIsland()->getCategory()
        ]));
    }

}