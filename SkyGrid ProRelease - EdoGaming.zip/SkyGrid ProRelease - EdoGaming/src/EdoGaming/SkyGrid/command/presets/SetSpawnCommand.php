<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\command\presets;


use skintrphoenix\AcidIsland\command\IslandCommand;
use skintrphoenix\AcidIsland\session\Session;
use skintrphoenix\AcidIsland\utils\message\MessageContainer;

class SetSpawnCommand extends IslandCommand {

    public function getName(): string {
        return "setspawn";
    }

    public function getUsageMessageContainer(): MessageContainer {
        return new MessageContainer("SET_SPAWN_USAGE");
    }

    public function getDescriptionMessageContainer(): MessageContainer {
        return new MessageContainer("SET_SPAWN_DESCRIPTION");
    }

    public function onCommand(Session $session, array $args): void {
        if($this->checkOfficer($session)) {
            return;
        } elseif($session->getPlayer()->getLevel() !== $session->getIsland()->getLevel()) {
            $session->sendTranslatedMessage(new MessageContainer("MUST_BE_IN_YOUR_ISLAND"));
        } else {
            $session->getIsland()->setSpawnLocation($session->getPlayer());
            $session->sendTranslatedMessage(new MessageContainer("SUCCESSFULLY_SET_SPAWN"));
        }
    }

}