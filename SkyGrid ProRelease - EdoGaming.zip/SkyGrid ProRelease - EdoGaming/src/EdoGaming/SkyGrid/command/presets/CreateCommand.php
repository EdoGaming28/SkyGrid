<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\command\presets;


use ReflectionException;
use skintrphoenix\AcidIsland\command\IslandCommand;
use skintrphoenix\AcidIsland\command\IslandCommandMap;
use skintrphoenix\AcidIsland\island\IslandFactory;
use skintrphoenix\AcidIsland\session\Session;
use skintrphoenix\AcidIsland\AcidIsland;
use skintrphoenix\AcidIsland\utils\message\MessageContainer;
use pocketmine\item\Item;

class CreateCommand extends IslandCommand {

    /** @var AcidIsland */
    private $plugin;

    public function __construct(IslandCommandMap $map) {
        $this->plugin = $map->getPlugin();
    }

    public function getName(): string {
        return "create";
    }

    public function getUsageMessageContainer(): MessageContainer {
        return new MessageContainer("CREATE_USAGE");
    }

    public function getDescriptionMessageContainer(): MessageContainer {
        return new MessageContainer("CREATE_DESCRIPTION");
    }

    /**
     * @throws ReflectionException
     */
    public function onCommand(Session $session, array $args): void {
        if($this->checkIslandAvailability($session) or $this->checkIslandCreationCooldown($session)) {
            return;
        }
        
        $generator = strtolower($args[0] ?? "Basic");
        if($this->plugin->getGeneratorManager()->isGenerator($generator) and $this->hasPermission($session, $generator)) {
            IslandFactory::createIslandFor($session, $generator);
            $session->sendTranslatedMessage(new MessageContainer("SUCCESSFULLY_CREATED_A_ISLAND"));
        } else {
            $session->sendTranslatedMessage(new MessageContainer("NOT_VALID_GENERATOR", ["name" => $generator]));
        }
    }

    private function hasPermission(Session $session, string $generator): bool {
        return $session->getPlayer()->hasPermission("AcidIsland.island.$generator");
    }

    private function checkIslandAvailability(Session $session): bool {
        $hasIsland = $session->hasIsland();
        if($hasIsland) {
            $session->sendTranslatedMessage(new MessageContainer("NEED_TO_BE_FREE"));
        }
        return $hasIsland;
    }

    private function checkIslandCreationCooldown(Session $session): bool {
        $minutesSinceLastIsland =
            $session->hasLastIslandCreationTime()
            ? (microtime(true) - $session->getLastIslandCreationTime()) / 60
            : -1;
        $cooldownDuration = $this->plugin->getSettings()->getCreationCooldownDuration();
        if($minutesSinceLastIsland !== -1 and $minutesSinceLastIsland < $cooldownDuration) {
            $session->sendTranslatedMessage(new MessageContainer("YOU_HAVE_TO_WAIT", [
                "minutes" => ceil($cooldownDuration - $minutesSinceLastIsland),
            ]));
            return true;
        }
        return false;
    }
    
    public function Book(Player $sender, Item $item){
        $inventory = $sender->getInventory();
        $inv = $sender->getInventory();
        $inv->addItem(Item::get(340));
        if($item->getId() == 340){
            $this->openUi($sender);
        }
    }
    public function openUi($sender){
        $api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function(Player $sender, int $data = null) {
            $result = $data;
            if($result == null){
                return true;
            }
            switch($result){
                case 0:
                break;
            }
        });
        $name = $sender->getName();
        $form->setTitle("Petunjuk");
        $form->setContent("§eSelamat datang Di SkyGrid! {$name}\n§aSkyGrid:\n\n§fSkyGrid Adalah Sebuah Dunia Yang Hanya Berisikan Block Melayang Di Kejauhan 4-5 block, Kamu Harus Bertahan Hidup Di Pulau SkyGrid Ini Dan Menamatkan The End, Kamu Bisa Bertahan Hidup Dengan Cara Menggambil Kayu, Makanan, Ore, Air, lava, obsidian, Dan Barang² Bagus Yang Ada Di Chest");
        $form->addButton("Sip!");
        $form->sendToPlayer($sender);
        return $form;
    }
}