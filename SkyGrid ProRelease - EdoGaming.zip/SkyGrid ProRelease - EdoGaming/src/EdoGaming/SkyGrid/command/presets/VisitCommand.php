<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\command\presets;


use ReflectionException;
use skintrphoenix\AcidIsland\command\IslandCommand;
use skintrphoenix\AcidIsland\command\IslandCommandMap;
use skintrphoenix\AcidIsland\session\Session;
use skintrphoenix\AcidIsland\AcidIsland;
use skintrphoenix\AcidIsland\utils\message\MessageContainer;

class VisitCommand extends IslandCommand {

    /** @var AcidIsland */
    private $plugin;

    public function __construct(IslandCommandMap $map) {
        $this->plugin = $map->getPlugin();
    }

    public function getName(): string {
        return "visit";
    }

    public function getAliases(): array {
        return ["teleport", "tp"];
    }

    public function getUsageMessageContainer(): MessageContainer {
        return new MessageContainer("VISIT_USAGE");
    }

    public function getDescriptionMessageContainer(): MessageContainer {
        return new MessageContainer("VISIT_DESCRIPTION");
    }

    /**
     * @throws ReflectionException
     */
    public function onCommand(Session $session, array $args): void {
        if(!isset($args[0])) {
            $session->sendTranslatedMessage(new MessageContainer("VISIT_USAGE"));
            return;
        }
        $offline = $this->plugin->getSessionManager()->getOfflineSession($args[0]);
        $islandId = $offline->getIslandId();
        if($islandId == null) {
            $session->sendTranslatedMessage(new MessageContainer("HE_DO_NOT_HAVE_AN_ISLAND", [
                "name" => $args[0]
            ]));
            return;
        }
        $this->plugin->getProvider()->loadIsland($islandId);
        $island = $this->plugin->getIslandManager()->getIsland($islandId);
        if($island->isLocked() and !($session->getPlayer()->isOp())) {
            $session->sendTranslatedMessage(new MessageContainer("HIS_ISLAND_IS_LOCKED", [
                "name" => $args[0]
            ]));
            $island->tryToClose();
            return;
        }
        $session->getPlayer()->teleport($island->getLevel()->getSpawnLocation());
        $session->sendTranslatedMessage(new MessageContainer("VISITING_ISLAND", [
            "name" => $args[0]
        ]));
    }

}