<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\command\presets;


use skintrphoenix\AcidIsland\island\RankIds;
use ReflectionException;
use skintrphoenix\AcidIsland\command\IslandCommand;
use skintrphoenix\AcidIsland\session\Session;
use skintrphoenix\AcidIsland\utils\message\MessageContainer;

class LeaveCommand extends IslandCommand {

    public function getName(): string {
        return "leave";
    }

    public function getUsageMessageContainer(): MessageContainer {
        return new MessageContainer("LEAVE_USAGE");
    }

    public function getDescriptionMessageContainer(): MessageContainer {
        return new MessageContainer("LEAVE_DESCRIPTION");
    }

    /**
     * @throws ReflectionException
     */
    public function onCommand(Session $session, array $args): void {
        if($this->checkIsland($session)) {
            return;
        } elseif($session->getRank() == RankIds::FOUNDER) {
            $session->sendTranslatedMessage(new MessageContainer("FOUNDER_CANNOT_LEAVE"));
            return;
        }
        $session->setRank(RankIds::MEMBER);
        $session->setIsland(null);
        $session->setInChat(false);
        $session->sendTranslatedMessage(new MessageContainer("LEFT_ISLAND"));
    }

}