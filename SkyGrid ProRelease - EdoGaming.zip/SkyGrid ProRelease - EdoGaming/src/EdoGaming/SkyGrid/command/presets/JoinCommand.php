<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\command\presets;


use skintrphoenix\AcidIsland\command\IslandCommand;
use skintrphoenix\AcidIsland\session\Session;
use skintrphoenix\AcidIsland\utils\message\MessageContainer;

class JoinCommand extends IslandCommand {

    public function getName(): string {
        return "join";
    }

    public function getAliases(): array {
        return ["go", "spawn", "home"];
    }

    public function getUsageMessageContainer(): MessageContainer {
        return new MessageContainer("JOIN_USAGE");
    }

    public function getDescriptionMessageContainer(): MessageContainer {
        return new MessageContainer("JOIN_DESCRIPTION");
    }

    public function onCommand(Session $session, array $args): void {
        if($this->checkIsland($session)) {
            return;
        }
        $session->getPlayer()->teleport($session->getIsland()->getLevel()->getSpawnLocation());
        $session->sendTranslatedMessage(new MessageContainer("TELEPORTED_TO_ISLAND"));
    }

}