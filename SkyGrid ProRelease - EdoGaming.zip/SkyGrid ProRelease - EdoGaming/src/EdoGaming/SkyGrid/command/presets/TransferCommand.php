<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\command\presets;


use skintrphoenix\AcidIsland\island\RankIds;
use skintrphoenix\AcidIsland\session\SessionLocator;
use ReflectionException;
use skintrphoenix\AcidIsland\command\IslandCommand;
use skintrphoenix\AcidIsland\command\IslandCommandMap;
use skintrphoenix\AcidIsland\session\Session;
use skintrphoenix\AcidIsland\AcidIsland;
use skintrphoenix\AcidIsland\utils\message\MessageContainer;

class TransferCommand extends IslandCommand {

    /** @var AcidIsland */
    private $plugin;

    public function __construct(IslandCommandMap $map) {
        $this->plugin = $map->getPlugin();
    }

    public function getName(): string {
        return "transfer";
    }

    public function getAliases(): array {
        return ["makeleader"];
    }

    public function getUsageMessageContainer(): MessageContainer {
        return new MessageContainer("TRANSFER_USAGE");
    }

    public function getDescriptionMessageContainer(): MessageContainer {
        return new MessageContainer("TRANSFER_DESCRIPTION");
    }

    /**
     * @throws ReflectionException
     */
    public function onCommand(Session $session, array $args): void {
        if($this->checkFounder($session)) {
            return;
        } elseif(!isset($args[0])) {
            $session->sendTranslatedMessage(new MessageContainer("TRANSFER_USAGE"));
            return;
        }
        $player = $this->plugin->getServer()->getPlayer($args[0]);
        if($player == null) {
            $session->sendTranslatedMessage(new MessageContainer("NOT_ONLINE_PLAYER", [
                "name" => $args[0]
            ]));
            return;
        }
        $playerSession = SessionLocator::getSession($player);
        if($this->checkClone($session, $playerSession)) {
            return;
        } elseif($playerSession->getIsland() !== $session->getIsland()) {
            $session->sendTranslatedMessage(new MessageContainer("MUST_BE_PART_OF_YOUR_ISLAND", [
                "name" => $playerSession->getName()
            ]));
            return;
        }
        $session->setRank(RankIds::MEMBER);
        $playerSession->setRank(RankIds::FOUNDER);
        $session->sendTranslatedMessage(new MessageContainer("TRANSFERRED", [
            "name" => $playerSession->getName()
        ]));
        $playerSession->sendTranslatedMessage(new MessageContainer("GOT_TRANSFERRED", [
            "name" => $session->getName()
        ]));
    }

}