<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\command\presets;


use skintrphoenix\AcidIsland\command\IslandCommand;
use skintrphoenix\AcidIsland\session\Session;
use skintrphoenix\AcidIsland\utils\message\MessageContainer;

class BlocksCommand extends IslandCommand {

    public function getName(): string {
        return "blocks";
    }

    public function getUsageMessageContainer(): MessageContainer {
        return new MessageContainer("BLOCKS_USAGE");
    }

    public function getDescriptionMessageContainer(): MessageContainer {
        return new MessageContainer("BLOCKS_DESCRIPTION");
    }

    public function onCommand(Session $session, array $args): void {
        if($this->checkIsland($session)) {
            return;
        }
        $session->sendTranslatedMessage(new MessageContainer("ISLAND_BLOCKS", [
            "amount" => $session->getIsland()->getBlocksBuilt()
        ]));
    }

}