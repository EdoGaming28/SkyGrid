<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\command\presets;


use ReflectionException;
use skintrphoenix\AcidIsland\command\IslandCommand;
use skintrphoenix\AcidIsland\session\Session;
use skintrphoenix\AcidIsland\utils\message\MessageContainer;

class AcceptCommand extends IslandCommand {

    public function getName(): string {
        return "accept";
    }

    public function getAliases(): array {
        return ["acc"];
    }

    public function getUsageMessageContainer(): MessageContainer {
        return new MessageContainer("ACCEPT_USAGE");
    }

    public function getDescriptionMessageContainer(): MessageContainer {
        return new MessageContainer("ACCEPT_DESCRIPTION");
    }

    /**
     * @throws ReflectionException
     */
    public function onCommand(Session $session, array $args): void {
        if($session->hasIsland()) {
            $session->sendTranslatedMessage(new MessageContainer("NEED_TO_BE_FREE"));
            return;
        }

        $invitation = null;
        if(isset($args[0]) and $session->hasInvitationFrom($args[0])) {
            $invitation = $session->getInvitationFrom($args[0]);
        } else {
            $invitation = $session->getLastInvitation();
        }

        if($invitation != null) {
            $invitation->accept();
        } else {
            $session->sendTranslatedMessage(new MessageContainer("ACCEPT_USAGE"));
        }
    }

}