<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\command\presets;


use skintrphoenix\AcidIsland\command\IslandCommand;
use skintrphoenix\AcidIsland\session\Session;
use skintrphoenix\AcidIsland\utils\message\MessageContainer;

class LockCommand extends IslandCommand {

    public function getName(): string {
        return "lock";
    }

    public function getUsageMessageContainer(): MessageContainer {
        return new MessageContainer("LOCK_USAGE");
    }

    public function getDescriptionMessageContainer(): MessageContainer {
        return new MessageContainer("LOCK_DESCRIPTION");
    }

    public function onCommand(Session $session, array $args): void {
        if($this->checkLeader($session)) {
            return;
        }
        $island = $session->getIsland();
        $island->setLocked(!$island->isLocked());
        $island->save();
        $session->sendTranslatedMessage(new MessageContainer($island->isLocked() ? "ISLAND_LOCKED" : "ISLAND_UNLOCKED"));
    }

}