<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\command;


use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginIdentifiableCommand;
use pocketmine\Player;
use pocketmine\plugin\Plugin;
use ReflectionException;
use skintrphoenix\AcidIsland\command\presets\AcceptCommand;
use skintrphoenix\AcidIsland\command\presets\BlocksCommand;
use skintrphoenix\AcidIsland\command\presets\CategoryCommand;
use skintrphoenix\AcidIsland\command\presets\ChatCommand;
use skintrphoenix\AcidIsland\command\presets\CooperateCommand;
use skintrphoenix\AcidIsland\command\presets\CreateCommand;
use skintrphoenix\AcidIsland\command\presets\DemoteCommand;
use skintrphoenix\AcidIsland\command\presets\DenyCommand;
use skintrphoenix\AcidIsland\command\presets\DisbandCommand;
use skintrphoenix\AcidIsland\command\presets\FireCommand;
use skintrphoenix\AcidIsland\command\presets\HelpCommand;
use skintrphoenix\AcidIsland\command\presets\InviteCommand;
use skintrphoenix\AcidIsland\command\presets\JoinCommand;
use skintrphoenix\AcidIsland\command\presets\BanishCommand;
use skintrphoenix\AcidIsland\command\presets\LeaveCommand;
use skintrphoenix\AcidIsland\command\presets\LockCommand;
use skintrphoenix\AcidIsland\command\presets\MembersCommand;
use skintrphoenix\AcidIsland\command\presets\PromoteCommand;
use skintrphoenix\AcidIsland\command\presets\SetSpawnCommand;
use skintrphoenix\AcidIsland\command\presets\TransferCommand;
use skintrphoenix\AcidIsland\command\presets\VisitCommand;
use skintrphoenix\AcidIsland\session\SessionLocator;
use skintrphoenix\AcidIsland\AcidIsland;
use skintrphoenix\AcidIsland\utils\message\MessageContainer;

class IslandCommandMap extends Command implements PluginIdentifiableCommand {

    /** @var AcidIsland */
    private $plugin;

    /** @var IslandCommand[] */
    private $commands = [];

    public function __construct(AcidIsland $plugin) {
        $this->plugin = $plugin;
        parent::__construct("isle", "SkyGrid command", "Usage: /sg", [
            "skygrid",
            "edo",
            "sky",
            "sgrd"
        ]);
        $plugin->getServer()->getCommandMap()->register("AcidIsland", $this);
    }

    /**
     * @return AcidIsland|Plugin
     */
    public function getPlugin(): Plugin {
        return $this->plugin;
    }

    /**
     * @return IslandCommand[]
     */
    public function getCommands(): array {
        return $this->commands;
    }

    public function getCommand(string $alias): ?IslandCommand {
        foreach($this->commands as $key => $command) {
            if(in_array(strtolower($alias), $command->getAliases()) or $alias == $command->getName()) {
                return $command;
            }
        }
        return null;
    }

    public function registerCommand(IslandCommand $command): void {
        $this->commands[$command->getName()] = $command;
    }

    public function unregisterCommand(string $commandName): void {
        if(isset($this->commands[$commandName])) {
            unset($this->commands[$commandName]);
        }
    }

    public function registerDefaultCommands(): void {
        $this->registerCommand(new HelpCommand($this));
        $this->registerCommand(new CreateCommand($this));
        $this->registerCommand(new JoinCommand());
        $this->registerCommand(new LockCommand());
        $this->registerCommand(new ChatCommand());
        $this->registerCommand(new VisitCommand($this));
        $this->registerCommand(new LeaveCommand());
        $this->registerCommand(new MembersCommand());
        $this->registerCommand(new InviteCommand($this));
        $this->registerCommand(new AcceptCommand());
        $this->registerCommand(new DenyCommand());
        $this->registerCommand(new DisbandCommand($this));
        $this->registerCommand(new BanishCommand());
        $this->registerCommand(new FireCommand($this));
        $this->registerCommand(new PromoteCommand());
        $this->registerCommand(new DemoteCommand());
        $this->registerCommand(new SetSpawnCommand());
        $this->registerCommand(new TransferCommand($this));
        $this->registerCommand(new CategoryCommand());
        $this->registerCommand(new BlocksCommand());
        $this->registerCommand(new CooperateCommand($this));
    }

    /**
     * @throws ReflectionException
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if(!$sender instanceof Player) {
            $sender->sendMessage("Please, run this command in game");
            return;
        }

        $session = SessionLocator::getSession($sender);
        if(isset($args[0]) and $this->getCommand($args[0]) != null) {
            $this->getCommand(array_shift($args))->onCommand($session, $args);
        } else {
            $session->sendTranslatedMessage(new MessageContainer("TRY_USING_HELP"));
        }
    }

}