<?php

declare(strict_types=1);

namespace skintrphoenix\AcidIsland\provider;


use skintrphoenix\AcidIsland\island\Island;
use skintrphoenix\AcidIsland\session\BaseSession;
use skintrphoenix\AcidIsland\AcidIsland;

abstract class Provider {

    /** @var AcidIsland */
    protected $plugin;

    public function __construct(AcidIsland $plugin) {
        $this->plugin = $plugin;
        $this->initialize();
    }

    public abstract function initialize(): void;

    public abstract function loadSession(BaseSession $session): void;

    public abstract function saveSession(BaseSession $session): void;

    public abstract function loadIsland(string $identifier): void;

    public abstract function saveIsland(Island $island): void;

}
